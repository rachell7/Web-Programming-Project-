window.onload=function(){
    document.getElementById("arrow").style.display="none"; //이동버튼 숨기기
    document.getElementById("ending").style.display="none";//글 숨기기
}
function function1(){
        document.getElementById("arrow").style.display='';//이동버튼 보이기
		document.getElementById("ending").style.display='';//글 보이기
        
}