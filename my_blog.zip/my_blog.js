function check(){
    var f=document.search;
    if(f.q.value==""){
        alert("공백입니다. 검색어를 입력하세요.");
        f.input.focus();
        return false;
}
}
